import { Hook } from '@oclif/core';
declare const migrate: Hook<'init'>;
export default migrate;
