import { Interfaces } from '@oclif/core';
declare const completions: Interfaces.Hook<'app' | 'addon' | 'config' | 'login' | 'logout'>;
export default completions;
