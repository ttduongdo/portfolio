export default function getNameAndRepo(args: any): Promise<any>;
