export declare function getAllVersionFlags(): any[];
export declare function getAllHelpFlags(): any[];
