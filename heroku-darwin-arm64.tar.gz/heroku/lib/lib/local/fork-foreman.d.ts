export declare function fork(argv: string[]): Promise<void>;
