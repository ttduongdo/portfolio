export declare function buildCommand(args: Array<string>): string;
export declare function buildEnvFromFlag(flag: string): {};
