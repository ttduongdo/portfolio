export declare function quote(s: string): string;
export declare function parse(a: string): string;
